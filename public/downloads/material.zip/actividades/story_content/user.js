function ExecuteScript(strId)
{
  switch (strId)
  {
      case "5nXYFl1CXUt":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

